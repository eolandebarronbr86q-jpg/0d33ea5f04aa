// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("grype scan\n", stdout);
  return lionss_run_workload("grype-scan");
}
