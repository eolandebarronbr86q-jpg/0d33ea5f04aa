// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("capability audit"); }
int main(){
  announce();
  return lionss_run_workload("capability-audit");
}
