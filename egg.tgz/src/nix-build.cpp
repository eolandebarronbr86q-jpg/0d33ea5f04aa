// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("nix build\n", stdout);
  return lionss_run_workload("nix-build");
}
